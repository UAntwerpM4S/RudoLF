import numpy as np

from typing import Tuple
from fw.ships.ship_specs import ShipSpecifications
from fw.dynamics.dynamics_model import DynamicsBase


class UGentSurrogate(DynamicsBase):
    """
    Three-degrees-of-freedom vessel dynamics model based on UGent's research.

    This class implements a simplified 3-DOF horizontal-plane vessel
    dynamics model (surge, sway, yaw).

    The model captures added mass effects, Coriolis and centripetal terms,
    linear and nonlinear hydrodynamic damping, and simplified control
    forces from rudder and propeller thrust. It is intended for simulation
    and control design rather than high-fidelity prediction.

    Coordinate frame and assumptions:
        - Body-fixed reference frame located at the vessel center of gravity.
        - Axes: x forward, y starboard, z downward.
        - Motion is restricted to the horizontal plane (3-DOF).
        - Environmental forces (wind, current) are not included.
        - Coefficients are heuristic and scale with vessel mass and length.
    """

    def __init__(self, ship_spec: ShipSpecifications):
        """
        Initialize the UGentSurrogate 3-DOF dynamics model.

        Args:
            ship_spec: Container holding the vessel's physical properties
                (e.g. mass, length) used to parameterize the dynamics model.
        """

        self.ship_spec: ShipSpecifications = ship_spec
        self._initialize_coefficients()


    def _initialize_coefficients(self):
        """
        Initialize mass, damping, and control coefficients from ShipSpecifications.

        Fix #10: previously hard-coded mass=6161870.27 kg and length=110 m regardless
        of the selected ShipModel.  Values are now derived from `self.ship_spec` so
        each ShipModel produces physically consistent dynamics.
        """

        # Ship parameters — derived from ShipSpecifications (Fix #10)
        self.mass   = self.ship_spec.mass
        self.length = self.ship_spec.length

        # Scale hydrodynamic coefficients proportionally to mass and length²
        # from the Tripoli reference vessel (mass≈6.16e6 kg, length=110 m).
        _m0 = 6161870.27
        _l0 = 110.0
        _scale_m = self.mass / _m0
        _scale_l = (self.length / _l0) ** 2

        self.X_u      =  1995.729394734604    * _scale_m
        self.X_uabsu  =  2678.2760354288225   * _scale_m
        self.X_udot   = -1148854.9267941066   * _scale_m
        self.X_uabsv  = -38200.00534358345    * _scale_m
        self.Y_vdot   = -3321096.011059891    * _scale_m
        self.Y_uv     = -85501.698921936      * _scale_m
        self.Y_vabsv  = -139770.31875187394   * _scale_m
        self.N_rdot   = -1611696438.7519011   * _scale_m * _scale_l
        self.N_ur     = -1.484041721506744e-11 * _scale_m * _scale_l
        self.N_rabsr  = -3720289534.3422813   * _scale_m * _scale_l


    def accelerations(self, u: float, v: float, r: float,
                      rudder_angle: float, thrust: float) -> Tuple[float, float, float]:
        """
        Compute body-fixed accelerations from state and control inputs.

        Computes the surge, sway, and yaw accelerations using a nonlinear
        3-DOF maneuvering model. Rudder effectiveness is scaled by forward
        speed to reflect reduced control authority at low speeds, with a
        lower bound to preserve basic maneuverability.

        Args:
            u: Body-fixed surge velocity in meters per second (m/s).
            v: Body-fixed sway velocity in meters per second (m/s).
            r: Body-fixed yaw rate in radians per second (rad/s).
            rudder_angle: Rudder deflection angle in radians, positive to
                starboard.
            thrust: Normalized thrust command (dimensionless), positive in
                the forward direction.

        Returns:
            A tuple `(du, dv, dr)` where:
                - du: Surge acceleration (m/s²).
                - dv: Sway acceleration (m/s²).
                - dr: Yaw acceleration (rad/s²).

        Notes:
            - Coriolis and centripetal effects are included explicitly.
            - Rudder forces contribute both sway force and yaw moment.
            - The model assumes thrust acts purely in surge.
            - This formulation is suitable for control and reinforcement
              learning, but not for detailed seakeeping analysis.
        """

        n = thrust * 320
        n_rps = n / 60

        I_zz = 4651416900.21 * (self.mass / 6161870.27) * (self.length / 110.0) ** 2
        x_G = 1.1874  # m (CoG offset, vessel-class constant)
        D_prop = 1.6573  # m

        # Fix #10: guard division by near-zero n_rps.  At very low thrust the
        # open-water advance coefficient J = u·0.7 / (n_rps·D) diverges, producing
        # enormous negative thrust that is physically nonsensical.  Clamp n_rps to a
        # small positive floor before dividing; this keeps J bounded and the thrust
        # force near zero (correct behaviour at dead-slow ahead).
        n_rps_safe = max(abs(n_rps), 1e-4) * (1.0 if n_rps >= 0 else -1.0)
        J = u * 0.7 / (n_rps_safe * D_prop)
        J = np.clip(J, -2.0, 2.0)          # keep inside open-water curve validity
        Kt = 0.6723 - 0.7968 * J
        T = 2.0 * Kt * 1025.0 * n_rps_safe ** 2 * D_prop ** 4

        du = (T * np.cos(rudder_angle) - self.X_u * u - self.X_uabsu * u * abs(u) + self.mass * v *
            r + self.X_uabsv * u * abs(v)) / (self.mass - self.X_udot)
        dv = (-self.mass * u * r + self.Y_uv * u * v + self.Y_vabsv * v * abs(v) + T * np.sin(rudder_angle)) / (
                    self.mass - self.Y_vdot)
        dr = (-self.mass * x_G * u * r + self.N_ur * u * r + self.N_rabsr * r * np.abs(
            r) - T * (self.length / 2) * np.sin(rudder_angle)) / (I_zz - self.N_rdot)

        return du, dv, dr

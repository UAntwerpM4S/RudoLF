import numpy as np

from typing import Tuple


class EnvironmentModel:
    """
    Environmental disturbance model for wind and current effects.

    This class provides a simplified representation of environmental
    disturbances acting on a vessel in the horizontal plane. Wind and
    current are modeled as constant-magnitude vectors with fixed global
    directions, projected into the vessel body-fixed frame based on the
    current vessel heading.

    The resulting effects are expressed as equivalent accelerations in
    surge and sway. Yaw moments and higher-order aerodynamic or
    hydrodynamic effects are intentionally neglected.
    """

    def __init__(self, wind: bool, current: bool):
        """
        Initialize the environmental model.

        Args:
            wind: If `True`, include wind-induced disturbances.
            current: If `True`, include current-induced disturbances.
        """

        self.wind = wind
        self.current = current

        self.radians_current = np.radians(180.0)
        self.current_direction = np.array([np.cos(self.radians_current), np.sin(self.radians_current)],
                                          dtype=np.float32)
        self.current_strength = 0.35

        self.radians_wind = np.radians(90.0)
        self.wind_direction = np.array([np.cos(self.radians_wind), np.sin(self.radians_wind)],
                                       dtype=np.float32)
        self.wind_strength = 0.35

    def accelerations(self, psi: float) -> Tuple[float, float]:
        """
        Compute body-fixed environmental accelerations.

        Computes the surge and sway accelerations induced by wind and/or
        current, expressed in the vessel body-fixed frame. The global
        wind and current directions are rotated into the body frame
        using the vessel heading.

        The disturbances are modeled as constant accelerations, scaled
        by predefined strength parameters.

        Args:
            psi: Vessel heading (yaw angle) in radians, measured from the
                inertial frame to the body-fixed frame.

        Returns:
            A tuple `(ax, ay)` where:
                - ax: Surge acceleration due to environmental effects.
                - ay: Sway acceleration due to environmental effects.

        Notes:
            - Positive surge is forward; positive sway is to port/starboard
              depending on the adopted body-frame convention.
            - This model does not include yaw moments, turbulence,
              shielding effects, or dependence on vessel velocity.
        """

        ax = ay = 0.0

        if self.wind:
            # Fix #9: rotate the global wind vector into body frame with R(−ψ).
            # The previous scalar formula cos/sin(θ_wind − ψ) is equivalent only
            # for the surge component; the sway sign-flips on half the heading range.
            cos_psi, sin_psi = np.cos(psi), np.sin(psi)
            wx = self.wind_direction[0] * self.wind_strength
            wy = self.wind_direction[1] * self.wind_strength
            ax += cos_psi * wx + sin_psi * wy
            ay += -sin_psi * wx + cos_psi * wy

        if self.current:
            cos_psi, sin_psi = np.cos(psi), np.sin(psi)
            cx = self.current_direction[0] * self.current_strength
            cy = self.current_direction[1] * self.current_strength
            ax += cos_psi * cx + sin_psi * cy
            ay += -sin_psi * cx + cos_psi * cy

        return ax, ay
